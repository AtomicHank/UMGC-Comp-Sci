/*
 * Student: Joe Merrill
 * Course: CMSC 430 Compiler Theory and Design
 * Project: Project 4
 * Date: 2026-04-06
 * File: listing.cc
 * Description: Implements the compilation listing format and counts lexical,
 * syntax, and semantic errors for each compiler run.
 */

#include <cstdio>
#include <string>
#include <vector>

using namespace std;

#include "listing.h"

static int lineNumber;
static int lexicalErrors;
static int syntaxErrors;
static int semanticErrors;
static vector<string> errors;

static void displayErrors() {
	for (size_t index = 0; index < errors.size(); index++) {
		printf("%s\n", errors[index].c_str());
	}
	errors.clear();
}

void firstLine() {
	lexicalErrors = 0;
	syntaxErrors = 0;
	semanticErrors = 0;
	lineNumber = 1;
	printf("\n%4d  ", lineNumber);
}

void nextLine() {
	displayErrors();
	lineNumber++;
	printf("%4d  ", lineNumber);
}

int lastLine() {
	printf("\r");
	displayErrors();
	printf("     \n");
	int totalErrors = lexicalErrors + syntaxErrors + semanticErrors;
	if (totalErrors > 0) {
		printf("Lexical Errors %d\n", lexicalErrors);
		printf("Syntax Errors %d\n", syntaxErrors);
		printf("Semantic Errors %d\n", semanticErrors);
	} else {
		printf("Compiled Successfully\n\n");
	}
	return totalErrors;
}

void appendError(ErrorCategories errorCategory, string message) {
	switch (errorCategory) {
		case LEXICAL:
			lexicalErrors++;
			errors.push_back("Lexical Error, Invalid Character " + message);
			break;
		case SYNTAX:
			syntaxErrors++;
			errors.push_back("Syntax Error, " + message);
			break;
		case GENERAL_SEMANTIC:
			semanticErrors++;
			errors.push_back("Semantic Error, " + message);
			break;
		case DUPLICATE_IDENTIFIER:
			semanticErrors++;
			errors.push_back("Semantic Error, Duplicate " + message);
			break;
		case UNDECLARED:
			semanticErrors++;
			errors.push_back("Semantic Error, Undeclared " + message);
			break;
	}
}
